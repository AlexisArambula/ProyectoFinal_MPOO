//
//  CUParkings.swift
//  map-test
//
//  Created by MacBook on 5/31/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import Foundation



var anexo = Parking(id: 0, name: "Anexo de Ingeniería", coordinate: Coordinate(latitude: 19.324423, longitude: -99.182769), totalSpaces: 30, usedSpaces: 22)


var principal = Parking(id: 1, name: "Facultad de Ingeniería", coordinate: Coordinate(latitude: 19.331113, longitude: -99.183484), totalSpaces: 60, usedSpaces: 15)


var futbol = Parking(id: 2, name: "Campos de Futbol", coordinate: Coordinate(latitude: 19.330300, longitude: -99.183208), totalSpaces: 20, usedSpaces: 20)


var parkings = [anexo, principal, futbol]


