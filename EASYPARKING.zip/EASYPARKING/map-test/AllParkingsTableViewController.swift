//
//  AllParkingsTableViewController.swift
//  map-test
//
//  Created by MacBook on 6/2/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import UIKit

class AllParkingsTableViewController: UITableViewController {

    
    var searchController: UISearchController!
    var filteredParkings = parkings
    
    var vc: MapViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createSearchBar()
    }
    
    func createSearchBar(){
        searchController = UISearchController(searchResultsController: nil)
        searchController.obscuresBackgroundDuringPresentation = false
        definesPresentationContext = true
        
        tableView.tableHeaderView = searchController.searchBar
        
        searchController.searchResultsUpdater = self
    }


    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredParkings.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "parkingCell", for: indexPath)
        
        let actualParking = filteredParkings[indexPath.row]
        
        
        cell.textLabel?.text = actualParking.name

        
        if actualParking.spaces.freeSpaces > 0 {
            cell.accessoryType = .checkmark
        }
        else {
            cell.accessoryType = .none
        }


        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        vc?.searchedParkingID = filteredParkings[indexPath.row].id
        navigationController?.popViewController(animated: true)
    }
    
    func filterParkingsForText(_ searchText: String){
        
        if searchText.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            filteredParkings = parkings
            tableView.reloadData()
            return
        }
        
        filteredParkings = parkings.filter({ (parking) -> Bool in
            return parking.name.lowercased().contains(searchText.lowercased())
        })
        tableView.reloadData()
    }
    

    
    
}


extension AllParkingsTableViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text {
            filterParkingsForText(searchText)
        }
    }
    
    
}
