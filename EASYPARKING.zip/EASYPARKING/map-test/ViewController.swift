//
//  ViewController.swift
//  map-test
//
//  Created by Macbook on 5/31/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var studentView: UIView!
    
    @IBOutlet weak var administratorView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setup()
    }

    func setup(){
        welcomeLabel.text = "Bienvenido\n a\n EasyParking"
        
        let backgroundGradientColors = [UIColor(red: 79/255, green: 172/255, blue: 254/255, alpha: 1).cgColor, UIColor(red: 0, green: 242/255, blue: 254/255, alpha: 1).cgColor]
        
        let backgroundGradient = generateGradient(colors: backgroundGradientColors, frame: backgroundView.frame)
        
        backgroundView.layer.addSublayer(backgroundGradient)
        
        let studentViewGradientColors = [UIColor(red: 67/255, green: 233/255, blue: 123/255, alpha: 1).cgColor, UIColor(red: 56/255, green: 249/255, blue: 215/255, alpha: 1).cgColor]
        
        let studentViewGradient = generateGradient(colors: studentViewGradientColors, frame: CGRect(x: 0, y: 0, width: studentView.frame.width , height: studentView.frame.height))
        
        
        studentViewGradient.cornerRadius = 10
        studentView.layer.insertSublayer(studentViewGradient, at: 0)
        studentView.layer.cornerRadius = 10

        
        let administratorViewGradientColors = [UIColor(red: 250/255, green: 112/255, blue: 154/255, alpha: 1).cgColor, UIColor(red: 254/255, green: 225/255, blue: 64/255, alpha: 1).cgColor]
        
        let administratorViewGradient = generateGradient(colors: administratorViewGradientColors, frame: CGRect(x: 0, y: 0, width: studentView.frame.width , height: studentView.frame.height))
        
        administratorViewGradient.cornerRadius = 10
        administratorView.layer.insertSublayer(administratorViewGradient, at: 0)
        administratorView.layer.cornerRadius = 10
    
        let studentTapGesture = UITapGestureRecognizer(target: self, action: #selector(setUserAsStudent))
        let administratorTapGesture = UITapGestureRecognizer(target: self, action: #selector(setUserAsAdministrator))
        
        studentView.addGestureRecognizer(studentTapGesture)
        administratorView.addGestureRecognizer(administratorTapGesture)
    }
    
    
    
    
    @objc func setUserAsStudent(){
        
        performSegue(withIdentifier: "student", sender: nil)
        
    }
    
    @objc func setUserAsAdministrator(){
        performSegue(withIdentifier: "administrator", sender: nil)
        
    }
    
    
    
    func generateGradient(colors: [CGColor], frame: CGRect) -> CAGradientLayer {
        let layer = CAGradientLayer()
        layer.colors = colors
        layer.startPoint = CGPoint(x: 0.50, y: 1.0)
        layer.endPoint = CGPoint(x: 0.5, y: 0.0)
        layer.frame = frame
        
        return layer
    }

}

