//
//  MoreInformationViewController.swift
//  map-test
//
//  Created by MacBook on 6/1/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import UIKit
import MapKit

class MoreInformationViewController: UIViewController {
    
    @IBOutlet weak var getDirectionsView: UIView!
    @IBOutlet weak var parkingImage: UIImageView!
    
    
    @IBOutlet weak var parkingTable: UITableView!
    
    let spinner = SpinnerViewController()
    
    
    var parking: Parking?
    var vc: UIViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        if let parking = self.parking {
            self.title = parking.name
            print(String(parking.id))
            self.parkingImage.image = UIImage(named: String(parking.id))
        }
        
        setup()

    }
    
    
    func setup(){
        getDirectionsView.layer.cornerRadius = 10
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(getDirections))
        getDirectionsView.addGestureRecognizer(tapGesture)
        
        parkingTable.delegate = self
        parkingTable.dataSource = self
        
        
    }
    
    
    @objc func getDirections(){
        
        print("routes requested")
        
        showSpinner()
        
        let request = MKDirections.Request()
        let vc = self.vc as! MapViewController
        let userCoordinate = vc.currentLocation!.coordinate
        
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: userCoordinate.latitude, longitude: userCoordinate.longitude), addressDictionary: nil))
        
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: parking!.coordinate.latitude, longitude: parking!.coordinate.longitude), addressDictionary: nil))
        
        
        request.requestsAlternateRoutes = true
        request.transportType = .automobile
        
        let directions = MKDirections(request: request)
        
        self.view.addSubview(UIActivityIndicatorView(style: .white))
        
        directions.calculate { [unowned self] response, error in
            
            guard let unwrappedResponse = response else {
                
                self.hideSpinner()
                
                let alert = UIAlertController(title: "No se encontraron rutas...", message: ":/", preferredStyle: .alert)
                let action = UIAlertAction(title: "Ok", style: .default)
                alert.addAction(action)
                
                self.present(alert, animated: true)
                
                return
            }
            
            let vc = self.vc as! MapViewController
            vc.routes = unwrappedResponse.routes
            
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    


}

extension MoreInformationViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        var message: String
        
        switch section {
        case 0:
            message = "Lugares Totales"
        case 1:
            message = "Lugares Disponibles"
        case 2:
            message = "Lugares Ocupados"
        default:
            message = "Ups"
        }
        
        return message
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "parkingCell", for: indexPath)
        
        guard let parking = self.parking else {return cell}
        
        
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = "\(parking.spaces.totalSpaces)"
        case 1:
            cell.textLabel?.text = "\(parking.spaces.freeSpaces)"
        case 2:
            cell.textLabel?.text = "\(parking.spaces.usedSpaces)"
        default:
            cell.textLabel?.text = "no debe aparecer"
        }
        
        return cell
    }
    
    
}

extension MoreInformationViewController {
    
    
    
    func showSpinner(){
        addChild(spinner)
        spinner.view.frame = view.frame
        view.addSubview(spinner.view)
        spinner.didMove(toParent: self)
    }
    
    func hideSpinner(){
        spinner.willMove(toParent: nil)
        spinner.view.removeFromSuperview()
        spinner.removeFromParent()
    }
    
}
