//
//  LoginViewController.swift
//  map-test
//
//  Created by MacBook on 6/3/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var userTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var loginBoardView: UIView!
    
    var adminParkingID: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        
        view.addGestureRecognizer(tapGesture)

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        userTextField.text = nil
        passwordTextField.text = nil
    }
    
    @objc func hideKeyboard(){
        view.endEditing(true)
    }
    
    
    @IBAction func login(_ sender: Any) {
        
        if let password = passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), password != "", let user = userTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), user != "" {
            print(password, user)

            
            if user == "estacionamiento1" && password == "1234"{
                adminParkingID = 0
                performSegue(withIdentifier: "adminPanel", sender: nil)
            }
            else if user == "estacionamiento2" && password == "1234"{
                adminParkingID = 1
                performSegue(withIdentifier: "adminPanel", sender: nil)
            }
            else if user == "estacionamiento3" && password == "1234"{
                adminParkingID = 2
                performSegue(withIdentifier: "adminPanel", sender: nil)
            }
            else {
                let alert = UIAlertController(title: "Error", message: "Usuario no encontrado", preferredStyle: .alert)
                let action = UIAlertAction(title: "Ok", style: .default)
                alert.addAction(action)
                present(alert, animated: true)
            }
            
        }
        else {
            let alert = UIAlertController(title: "Datos faltantes", message: "Porfavor revise el usuario y la contraseña", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default)
            
            alert.addAction(action)
            present(alert, animated: true)
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "adminPanel"{
            let vc = segue.destination as! AdminPanelViewController
            vc.parkingID = adminParkingID!
        }
    }
    
}
