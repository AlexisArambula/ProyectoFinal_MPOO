//
//  Parking.swift
//  map-test
//
//  Created by MacBook on 5/31/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

struct Coordinate {
    let latitude: Double
    let longitude: Double
}

struct Spaces {
    let totalSpaces: Int
    var usedSpaces: Int
    var freeSpaces: Int
}

struct Parking {
    let id: Int
    let name: String
    let coordinate: Coordinate
    var spaces: Spaces
    
    init(id: Int, name: String, coordinate: Coordinate, totalSpaces: Int, usedSpaces: Int) {
        self.id = id
        self.name = name
        self.coordinate = coordinate
        
        self.spaces = Spaces(totalSpaces: totalSpaces, usedSpaces: usedSpaces, freeSpaces: totalSpaces - usedSpaces)
    }
    
}

