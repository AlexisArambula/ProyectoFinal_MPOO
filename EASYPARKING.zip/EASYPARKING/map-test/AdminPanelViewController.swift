//
//  AdminPanelViewController.swift
//  map-test
//
//  Created by MacBook on 6/3/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import UIKit

class AdminPanelViewController: UIViewController {

    @IBOutlet weak var parkingImage: UIImageView!
    @IBOutlet weak var carOutView: UIView!
    @IBOutlet weak var carInView: UIView!
    
    @IBOutlet weak var table: UITableView!
    
    var parkingID: Int?
    
    var parking: Parking?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table.delegate = self
        table.dataSource = self
        
        if let index = parkingID{
            parking = parkings[index]
            parkingImage.image = UIImage(named: String(parking!.id))
            title = parking?.name
            navigationController?.navigationBar.prefersLargeTitles = true
            navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .stop, target: self, action: #selector(logout))
        }
        
        setup()
    }
    
    @objc func logout(){
        navigationController?.popViewController(animated: true)
    }
    
    func setup(){
        
        navigationItem.setHidesBackButton(true, animated: false)
        
        let carInTapGesture = UITapGestureRecognizer(target: self, action: #selector(carEnter))
        let carOutTapGesture = UITapGestureRecognizer(target: self, action: #selector(carExit))
        
        carInView.addGestureRecognizer(carInTapGesture)
        carInView.layer.cornerRadius = 10
        
        carOutView.addGestureRecognizer(carOutTapGesture)
        carOutView.layer.cornerRadius = 10
    }
    
    @objc func carEnter(){
        if parking?.spaces.freeSpaces == 0{
            let alert = UIAlertController(title: "Lugares no disponibles", message: "Ya no quedan lugares", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default)
            alert.addAction(action)
            present(alert, animated: true)
            return
        }
        parking?.spaces.freeSpaces -= 1
        parking?.spaces.usedSpaces += 1
        table.reloadData()
    }
    
    @objc func carExit(){
        if parking?.spaces.usedSpaces == 0{
            let alert = UIAlertController(title: "No hay ningun lugar utilizado", message: nil, preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default)
            alert.addAction(action)
            present(alert, animated: true)
            return
        }
        parking?.spaces.freeSpaces += 1
        parking?.spaces.usedSpaces -= 1
        table.reloadData()
    }
    

}

extension AdminPanelViewController: UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        var message: String
        
        switch section {
        case 0:
            message = "Lugares Totales"
        case 1:
            message = "Lugares Disponibles"
        case 2:
            message = "Lugares Ocupados"
        default:
            message = "Ups"
        }
        
        return message
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "parkingCell", for: indexPath)
        
        guard let parking = self.parking else {return cell}
        
        
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = "\(parking.spaces.totalSpaces)"
        case 1:
            cell.textLabel?.text = "\(parking.spaces.freeSpaces)"
        case 2:
            cell.textLabel?.text = "\(parking.spaces.usedSpaces)"
        default:
            cell.textLabel?.text = "no debe aparecer"
        }
        
        return cell
    }
    
}
