//
//  MapViewController.swift
//  map-test
//
//  Created by MacBook on 5/31/19.
//  Copyright © 2019 UNAM. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class MapViewController: UIViewController {
    
    @IBOutlet weak var moreInformationView: UIView!
    @IBOutlet weak var map: MKMapView!
    
    
    
    var locationManager: CLLocationManager!
    var currentLocation: CLLocation?
    
    
    var selectedParkingID: Int?
    
    var routes: [MKRoute]?
    
    var searchedParkingID: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        map.delegate = self
        
        map.showsUserLocation = true

        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        
        addAnnotations()
        
        setUp()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        map.removeOverlays(map.overlays)
        
        if let routes = routes {
            
            if let route = routes.last {
                map.addOverlay(route.polyline)
                map.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            }
            
            
        }
        
        if let parkingId = searchedParkingID {
            let actualParking = parkings[parkingId]
            let actualCoordinate = CLLocationCoordinate2D(latitude: actualParking.coordinate.latitude, longitude: actualParking.coordinate.longitude)
            
            let region = MKCoordinateRegion(center: actualCoordinate, latitudinalMeters: 250, longitudinalMeters: 250)
            
            DispatchQueue.main.async {
                self.map.setRegion(region, animated: true)
            }
        }
        
    }
    
    func setUp(){
        
        
        self.title = "Estacionamientos"
        
        moreInformationView.layer.cornerRadius = 10
        moreInformationView.isHidden = true
        moreInformationView.alpha = 0
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(showMoreInformation))
        moreInformationView.addGestureRecognizer(tapGesture)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .search, target: self, action: #selector(showAllParkings))
    }
    
    func addAnnotations(){
        for parking in parkings {
            let annotation = MapMarker(title: parking.name, id: parking.id, coordinate: CLLocationCoordinate2D(latitude: parking.coordinate.latitude, longitude: parking.coordinate.longitude))
            map.addAnnotation(annotation)
        }
    }
    
    func showMoreInfoButton() {
        moreInformationView.isHidden = false
        moreInformationView.alpha = 1
    }
    
    func hideMoreInfoButton(){
        moreInformationView.isHidden = true
        moreInformationView.alpha = 0
    }
    
    
    @IBAction func changeMapType(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 0:
            map.mapType = .standard
        case 1:
            map.mapType = .satellite
        case 2:
            map.mapType = .hybrid
        default:
            map.mapType = .standard
        }
        
    }
    
    @objc func showMoreInformation(){
        performSegue(withIdentifier: "moreInformation", sender: nil)
    }
    
    @objc func showAllParkings(){
        performSegue(withIdentifier: "allParkings", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.routes = nil
        self.searchedParkingID = nil
        
        if segue.identifier == "moreInformation"{
            let vc = segue.destination as! MoreInformationViewController
            vc.parking = parkings[selectedParkingID!]
            vc.vc = self
        }
        
        if segue.identifier == "allParkings" {
            selectedParkingID = nil
            hideMoreInfoButton()
            let vc = segue.destination as! AllParkingsTableViewController
            vc.vc = self
        }
    }

    
    
}

extension MapViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        guard let annotation = annotation as? MapMarker else { return nil }
        let identifier = "mapMarker"
        var view: MKMarkerAnnotationView

        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {

            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: 0, y: 20)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        
        view.rightCalloutAccessoryView?.isHidden = true
        view.leftCalloutAccessoryView = view.rightCalloutAccessoryView
        
        return view
    
    
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard let annotation = view.annotation as? MapMarker else {return}
        selectedParkingID = annotation.id
        showMoreInfoButton()
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        guard view.annotation is MapMarker else {return}
        selectedParkingID = nil
        hideMoreInfoButton()
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(polyline: overlay as! MKPolyline)
        renderer.strokeColor = UIColor.cyan
        renderer.lineWidth = 4
        return renderer
    }
    
    
    
    
}


extension MapViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            locationManager.stopUpdatingLocation()
            currentLocation = location
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 750, longitudinalMeters: 750)
            
            DispatchQueue.main.async {
                self.map.setRegion(region, animated: true)
            }
        }
    }
}
